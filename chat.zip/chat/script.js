var pcmob = document.getElementById ('pcmob');
var inputs = document.getElementById ('inputn');
var input2 = document.getElementById ('input2');
var fec = document.getElementById ('drivered');
var btn = document.getElementById ('btn');
var ch = document.getElementById ('ch');
var chat = document.getElementById ('cchat');
var csender = document.getElementById ("chc");
var ctitle = document.getElementById ("ctitle");
var visibility = "on";
var navbar = document.getElementById ("navbar");
var a1 = document.getElementById ("a1");
var a2 = document.getElementById ("a2");
var a3 = document.getElementById ("a3");
var a4 = document.getElementById ("a4");
var a5 = document.getElementById ("a5");

function hideshow() {
  if (visibility == "on") {
    visibility = "off";
    navbar.classList.add ("offanime");
    navbar.style.height = "60px";
    a1.style.display = "none";
    a2.style.display = "none";
    a3.style.display = "none";
    a4.style.display = "none";
    a5.style.display = "none";
    $ ("#navbar").one ('webkitAnimationEnd oanimationend msAnimationEnd animationend',
      function (e) {
        $ ('#navbar').removeClass ('offanime');
      });

  } else
  {
    visibility = "on";
    navbar.classList.add ("onanime");
    navbar.style.height = "100%";
    a1.style.display = "block";
    a2.style.display = "block";
    a3.style.display = "block";
    a4.style.display = "block";
    a5.style.display = "block";
    $ ("#navbar").one ('webkitAnimationEnd oanimationend msAnimationEnd animationend',
      function (e) {
        $ ('#navbar').removeClass ('onanime');
      });
  }
}


  pcmob.style.float = 'right';
  chat.style.float = 'right';

  pcmob.style.width = ($(window).width()-37);
  chat.style.width = ($(window).width()-37);
  cchat.style.height = "50px";
  ctitle.style.height = "60px";

$ (function () {
  $ ('form').on ('submit', function (e) {
    if (input2.value.match(/^\s*$/)) {
      e.preventDefault ();
      alert("😤😤😤 input is empty");
    } else {
      e.preventDefault ();
      sending ();
      alert("you will sent :"+ input2.value);
      $.ajax ( {
        type: 'post',
        url: 'post.php',
        data: $ ('form').serialize (),
        success: function () {
          alert("success !");
          sent();
        }
      });
    }
  });
});


function sending() {
  var spans = document.getElementById ("spans");
  var cmsg = input2.value;
  if (cmsg != "chouaib") {
    var nsdiv = document.createElement ("div");
    nsdiv.classList.add ('csender');
    var nctable = document.createElement("table");
    var nctrs = document.createElement("tr");
    var nctds = document.createElement("td");
    var nctrr = document.createElement("tr");
    var nctdr = document.createElement("td");
    var nsi = document.createElement("i");
    var nsiu = document.createElement("span");
    var seh = document.createTextNode("sending ..");
    var text = document.createTextNode(cmsg);
    nsiu.appendChild(seh);

    nsi.appendChild(text);
    nctable.appendChild(nctrs);
    nctable.appendChild(nctrr);
    nctrs.appendChild(nctds);
    nctrr.appendChild(nctdr);
    nctds.appendChild(nsi);
    nctdr.appendChild(nsiu);
    nsdiv.appendChild (nctable);
    nsiu.classList.add("just");
    input2.value = "";
    
    csender.appendChild (nsdiv);
    
    spans.innerHTML = "sending ..";
  } else {
    var nsdiv = document.createElement ("div");
    nsdiv.classList.add ('creceiver');
    var nctable = document.createElement("table");
    var nctrs = document.createElement("tr");
    var nctds = document.createElement("td");
    var nctrr = document.createElement("tr");
    var nctdr = document.createElement("td");
    var nsi = document.createElement("i");
    var nsiu = document.createElement("span");
    var seh = document.createTextNode("sending ..");
    var text = document.createTextNode(cmsg);
    nsiu.appendChild(seh);
    nsiu.classList.add("just");
    nsi.appendChild(text);
    nctable.appendChild(nctrs);
    nctable.appendChild(nctrr);
    nctrs.appendChild(nctds);
    nctrr.appendChild(nctdr);
    nctds.appendChild(nsi);
    nctdr.appendChild(nsiu);
    nsdiv.appendChild (nctable);

    input2.value = "";
    csender.appendChild (nsdiv);
    spans.innerHTML = "sending ..";
  }
}

function sent() {
  var spanss = document.getElementsByClassName("just");
  for (i = 0; i < spanss.length; i++) {
    spanss[i].innerHTML = "sent !";
    spanss[i].parentNode.style.display = "none";
    spanss[i].parentNode.parentNode.style.display = "none";
  }

}

window.setInterval(function() {
  if (input2.value.match(/^\s*$/) || input2.value == "") {
    $("#himn").addClass("disabled");
  } else {
    $("#himn").removeClass("disabled");
  }
}, 100);